package Mahasiswa;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hp
 */
public class Mahasiswa {
    
    public void membaca(){
        System.out.println("Membaca");
    }
    public void nyontek(){
        System.out.println("Jangan Nyontek ");
    }
    public void modifikasi(){
        System.out.println("Modifikasi");
    }
        
}
