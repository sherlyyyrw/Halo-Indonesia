package Matematika;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hp
 */
public class Matematika {
    
    void pertambahan(int A, int B){
        System.out.println(A + "+" + B + "=" + (A+B));
    }
    void pengurangan(int A, int B){
        System.out.println(A + "-" + B + "=" + (A-B));
    }
    void perkalian(int A, int B){
        System.out.println(A + "*" + B + "=" + (A*B));
        
    }
    void pembagian(double A, double B){
        System.out.println(A + "/" + B + "=" + (A/B));
    }
    
}
