/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Matematika;

/**
 *
 * @author hp
 */
public class MatematikaCanggih {
    public void pertambahan(double a, double b){
        System.out.println("Pertambahan: "+a+"+ "+b+" ="+(a+b));
    }
    public void pengurangan(double a, double b){
        System.out.println("Pertambahan: "+a+" - "+b+" ="+(a-b));
        
    }
    public void perkalian(double a, double b){
        System.out.println("Pertambahan: "+a+" * "+b+" ="+(a*b));
    }
    public void pembagian(double a, double b){
        System.out.println("Pertambahan: "+a+" / "+b+" ="+(a/b));
    }
    public void pertambahan(double a, double b, double c){
        System.out.println("Pertambahan: "+a+" + "+b+" + "+c+" ="+(a+b+c));
    }
   public void pengurangan(double a, double b, double c){
        System.out.println("Pertambahan: "+a+" - "+b+" - "+c+" ="+(a-b-c));
    }
   public void perkalian(double a, double b, double c){
        System.out.println("Pertambahan: "+a+" * "+b+" * "+c+" ="+(a*b*c));
    }
   public void pembagian(double a, double b, double c){
        System.out.println("Pertambahan: "+a+" / "+b+" / "+c+" ="+(a/b/c));
    }
   public void modulus (int a, int b){
       System.out.println("Modulus: "+a+" % "+b+" = " +(a%b));
   } 
   
    }
    
    
    
    

