/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package hp;

/**
 *
 * @author hp
 */
public class Handphone {
    
    public void hidupkan(){
        System.out.println("Handphone hidup...");
    }
    public void lakukanPanggilan(){
        System.out.println("kring, kring, kring ../. panggilan dilakukan");
        
    }
    public void kirimSMS(){
        System.out.println("Dung, dung ... sms berhasil terkirim");
    }
    
    public void matikan(){
        System.out.println("Handphone mati..."); 
                
    }
    
    
}
